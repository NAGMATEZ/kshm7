import pandas as pd
import matplotlib.pyplot as plt

# DataFrame beolvasása
df = pd.read_excel('ferfiak.xlsx', skiprows=2)
oszlopok={
    'Unnamed: 1':'2004',
    'Unnamed: 2':'2005',
    'Unnamed: 3':'2006',
    'Unnamed: 4':'2007',
    'Unnamed: 5':'2008',
    'Unnamed: 6':'2009',
    'Unnamed: 7':'2010',
    'Unnamed: 8':'2011',
    'Unnamed: 9':'2012',
    'Unnamed: 10':'2013',
    'Unnamed: 11':'2014',
    'Unnamed: 12':'2015',
    'Unnamed: 13':'2016',
    'Unnamed: 14':'2017',
    'Unnamed: 15':'2018',
    'Unnamed: 16':'2019',
    'Unnamed: 17':'2020',
    'Unnamed: 18':'2021'
}
df.rename(columns=oszlopok, inplace=True)
sorok= {
    0: 'Ausztria', 1: 'Belgium', 2: 'Bulgária', 3: 'Ciprus', 4: 'Csehország', 5: 'Dánia', 6: 'Észtország', 7: 'Finnország', 8: 'Franciaország', 9: 'Görögország', 10: 'Hollandia', 11: 'Horvátország', 12: 'Írország', 13: 'Lengyelország', 14: 'Lettország', 15: 'Litvánia', 16: 'Luxemburg', 17: 'Magyarország', 18: 'Málta', 19: 'Németország', 20: 'Olaszország', 21: 'Portugália', 22: 'Románia', 23: 'Spanyolország', 24: 'Svédország', 25: 'Szlovákia', 26: 'Szlovénia', 27: 'EU27_2020', 28: 'Egyesült Királyság', 29: 'Norvégia', 30: 'Svájc'
}
df.rename(index=sorok, inplace=True)
df.replace("..", 0, inplace=True)
df.plot()
plt.show()
df.plot(kind='bar')
plt.show()
